package com.sunventure.claimportal.springbootbackend.service;

public interface EmployeeService {

}
