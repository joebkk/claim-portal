package com.sunventure.claimportal.springbootbackend.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunventure.claimportal.springbootbackend.domain.Claim;
import com.sunventure.claimportal.springbootbackend.repo.ClaimRepo;

import jakarta.persistence.EntityManager;

@Service
public class ClaimServiceImpl implements ClaimService {
	
	private ClaimRepo claimRepo;
	private EntityManager entityManager; 
    
    @Autowired
	public ClaimServiceImpl(ClaimRepo claimRepo, EntityManager entityManager) {
		this.claimRepo = claimRepo;
		this.entityManager = entityManager;
	}
	
    @Override
	public Claim create(Claim claim) {
		Claim c = claimRepo.save(claim);
		return c;
	}
    
    @Override
	public List<Claim> findAll() {
    	List<Claim> claims = claimRepo.findAll();
		return claims;
	}
    
    @Override
	public List<Claim> findByEmployeeId(Integer employeeId) {
    	List<Claim> claims = claimRepo.findByEmployeeId(employeeId);
		return claims;
	}
    
    @Override
	public List<Claim> findByManagerId(Integer managerId) {
    	List<Claim> claims = claimRepo.findByManagerId(managerId);
		return claims;
	}
    
    @Override
	public List<Claim> updateClaims(List<Claim> claims) {
    	List<Claim> output = new ArrayList<>();
    	for (Claim claim : claims) {
    		output.add(claimRepo.save(claim));
    	}
		return output;
	}
}
