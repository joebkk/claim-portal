package com.sunventure.claimportal.springbootbackend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunventure.claimportal.springbootbackend.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
private EmployeeRepo employeeRepo;
    
    @Autowired
	public EmployeeServiceImpl(EmployeeRepo employeeRepo) {
		this.employeeRepo = employeeRepo;
	}

}
