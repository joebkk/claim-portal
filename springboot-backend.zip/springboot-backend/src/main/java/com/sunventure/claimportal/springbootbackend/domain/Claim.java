package com.sunventure.claimportal.springbootbackend.domain;

import java.util.Date;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="CLAIM")
public class Claim {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer claimId;
    private Integer employeeId;
    private Integer managerId;
    private String category;
    private String description;
    private String status;
    private Double amount;    
    private Date submittedDate;

    public Claim() {

    }

	public Claim(Integer claimId, Integer employeeId, Integer managerId, String category, String description,
			String status, Double amount, Date submittedDate) {
		super();
		this.claimId = claimId;
		this.employeeId = employeeId;
		this.managerId = managerId;
		this.category = category;
		this.description = description;
		this.status = status;
		this.amount = amount;
		this.submittedDate = submittedDate;
	}	

	public Integer getClaimId() {
		return claimId;
	}

	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	
	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public int hashCode() {
		int result = claimId != null ? claimId.hashCode() : 0;
        result = 31 * result + (employeeId != null ? employeeId.hashCode() : 0);
        return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Claim other = (Claim) obj;
		return Objects.equals(amount, other.amount) && Objects.equals(category, other.category)
				&& Objects.equals(claimId, other.claimId) && Objects.equals(description, other.description)
				&& Objects.equals(employeeId, other.employeeId) && Objects.equals(managerId, other.managerId)
				&& Objects.equals(status, other.status) && Objects.equals(submittedDate, other.submittedDate);
	}

	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", employeeId=" + employeeId + ", managerId=" + managerId + ", category="
				+ category + ", description=" + description + ", status=" + status + ", amount=" + amount
				+ ", submittedDate=" + submittedDate + "]";
	}
}
