package com.sunventure.claimportal.springbootbackend.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunventure.claimportal.springbootbackend.domain.Claim;
import com.sunventure.claimportal.springbootbackend.service.EmployeeService;

@CrossOrigin("*")
@RequestMapping("/api")
@RestController
public class EmployeeController {
	
	private EmployeeService employeeService;
    
    @Autowired
   	public EmployeeController(EmployeeService employeeService) {
   		this.employeeService = employeeService;
   	}
    
}
