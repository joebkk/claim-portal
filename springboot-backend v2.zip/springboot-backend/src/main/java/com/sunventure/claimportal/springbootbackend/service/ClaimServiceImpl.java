package com.sunventure.claimportal.springbootbackend.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunventure.claimportal.springbootbackend.domain.Claim;
import com.sunventure.claimportal.springbootbackend.domain.Employee;
import com.sunventure.claimportal.springbootbackend.repo.ClaimRepo;
import com.sunventure.claimportal.springbootbackend.repo.EmployeeRepo;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
public class ClaimServiceImpl implements ClaimService {
	
	private ClaimRepo claimRepo;
	private EmployeeRepo employeeRepo;
	private EntityManager entityManager; 
    
    @Autowired
	public ClaimServiceImpl(ClaimRepo claimRepo, EmployeeRepo employeeRepo, EntityManager entityManager) {
		this.claimRepo = claimRepo;
		this.employeeRepo = employeeRepo;
		this.entityManager = entityManager;
	}
	
    @Override
    @Transactional
	public Claim create(Claim claim) {
    	Optional<Employee> optionalEmployee = employeeRepo.findById(claim.getEmployee().getId());
    	if (optionalEmployee.isPresent()) {
    		claim.setEmployee(optionalEmployee.get());
		}
    	Claim c = entityManager.merge(claim);
		return c;
	}
    
    
    @Override
	public List<Claim> findAll() {
    	List<Claim> claims = claimRepo.findAll();
		return claims;
	}
    
    @Override
	public List<Claim> findByEmployeeId(Integer employeeId) {
    	List<Claim> claims = claimRepo.findByEmployeeId(employeeId);
		return claims;
	}
        
    @Override
	public List<Claim> findByManagerId(Integer managerId) {
    	List<Claim> claims = claimRepo.findByManagerId(managerId);
		return claims;
	}
    
    @Override
	public List<Claim> updateClaims(List<Claim> claims) {
    	List<Claim> output = new ArrayList<>();
    	for (Claim claim : claims) {
    		Optional<Claim> optionalClaim = claimRepo.findById(claim.getClaimId());
    		if (optionalClaim.isPresent()) {
    			Claim updateClaim = optionalClaim.get();
    			updateClaim.setStatus(claim.getStatus());
    			output.add(claimRepo.save(updateClaim));
    		}
    	}
		return output;
	}
}
