package com.sunventure.claimportal.springbootbackend.service;

import com.sunventure.claimportal.springbootbackend.domain.Employee;

public interface EmployeeService {
	
	public Employee findByEmployeeId(Integer id);

}
