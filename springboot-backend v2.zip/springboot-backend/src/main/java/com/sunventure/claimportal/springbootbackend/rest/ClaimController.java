package com.sunventure.claimportal.springbootbackend.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunventure.claimportal.springbootbackend.domain.Claim;
import com.sunventure.claimportal.springbootbackend.domain.Employee;
import com.sunventure.claimportal.springbootbackend.service.ClaimService;
import com.sunventure.claimportal.springbootbackend.service.EmployeeService;

@CrossOrigin("*")
@RequestMapping("/api")
@RestController
public class ClaimController {
	
	private ClaimService claimService;
	private EmployeeService employeeService;
	    
    @Autowired
   	public ClaimController(ClaimService claimService, EmployeeService employeeService) {
   		this.claimService = claimService;
   		this.employeeService = employeeService;
   	}
    
    @PostMapping(value = "/claims")
    ResponseEntity<Claim> create(@RequestBody Claim claim) {
    	Claim output = claimService.create(claim);
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
    
    @GetMapping(value = "/claims")
    ResponseEntity<List<Claim>> findAll() {
    	List<Claim> output = claimService.findAll();
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
    
    @PutMapping(value = "/claims")
    ResponseEntity<List<Claim>> updateStatus(@RequestBody List<Claim> claims) {
    	List<Claim> output = claimService.updateClaims(claims);    	
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
        
    @GetMapping(value = "/claims/manager/{id}")
    ResponseEntity<List<Claim>> findByManagerId(@PathVariable("id") int id) {
    	List<Claim> output = claimService.findByManagerId(id);
        return new ResponseEntity<>(output, HttpStatus.OK);
    }
    
    @GetMapping(value = "/claims/employee/{id}")
    ResponseEntity<Employee> findByEmployeeId(@PathVariable("id") int id) {
    	Employee output = employeeService.findByEmployeeId(id);
        return new ResponseEntity<>(output, HttpStatus.OK);
        
    }
}
