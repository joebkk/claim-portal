package com.sunventure.claimportal.springbootbackend.service;

import java.util.List;

import com.sunventure.claimportal.springbootbackend.domain.Claim;

public interface ClaimService {
	
	public Claim create(Claim claim);
	public List<Claim> findAll();
	public List<Claim> findByManagerId(Integer managerId);
	public List<Claim> updateClaims(List<Claim> claims);
	public List<Claim> findByEmployeeId(Integer id);
}
