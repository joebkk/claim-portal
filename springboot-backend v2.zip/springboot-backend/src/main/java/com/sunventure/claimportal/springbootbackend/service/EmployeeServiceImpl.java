package com.sunventure.claimportal.springbootbackend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunventure.claimportal.springbootbackend.domain.Employee;
import com.sunventure.claimportal.springbootbackend.repo.ClaimRepo;
import com.sunventure.claimportal.springbootbackend.repo.EmployeeRepo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private ClaimRepo claimRepo;
	private EmployeeRepo employeeRepo;
	private EntityManager entityManager; 

    
    @Autowired
	public EmployeeServiceImpl(ClaimRepo claimRepo, EmployeeRepo employeeRepo, EntityManager entityManager) {
    	this.claimRepo = claimRepo;
		this.employeeRepo = employeeRepo;
		this.entityManager = entityManager;
	}
    
    @Override
    public Employee findByEmployeeId(Integer id) {
    	Employee employee = null;
    	
    	String strQuery = "SELECT e FROM Employee e JOIN FETCH e.claims WHERE e.id = :employeeId";
    	TypedQuery<Employee> query = entityManager.createQuery(strQuery, Employee.class);
    	query.setParameter("employeeId", id);
    	try {
    		employee = query.getSingleResult();
    	} catch(NoResultException ne) {
    		ne.printStackTrace();
    	}
    	
    	return employee;
    }
}
