package com.sunventure.claimportal.springbootbackend.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sunventure.claimportal.springbootbackend.domain.Claim;

@Repository
public interface ClaimRepo extends JpaRepository<Claim, Integer> {
	
	List<Claim> findByEmployeeId(Integer employeeId);
	List<Claim> findByManagerId(Integer managerId);
	
}
