import React, { useState } from "react";
import { Button, Form, Input, Message } from 'semantic-ui-react'
import { useNavigate } from "react-router-dom";
import './App.css';

const Login = () => {
  const navigate = useNavigate();
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [showLoginError, setShowLoginError] = useState(false);
  const [credential, setCredential] = useState();
  const users = [
    { username: "101", password: "101" }, 
    { username: "102", password: "102" }
  ];
  const managers = [
    { username: "401", password: "401" }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const empAccount = users.find((user) => user.username === username);
    if (empAccount && empAccount.password === password) {
      localStorage.setItem("authenEmployee", true);
      localStorage.setItem("loginUser", username);
      setShowLoginError(false);
      navigate("/EmployeeHome");
    } else {
      setShowLoginError(true);
    }

    const mgrAccount = managers.find((user) => user.username === username);
    if (mgrAccount && mgrAccount.password === password) {
      localStorage.setItem("authenManager", true);
      localStorage.setItem("loginUser", username);
      setShowLoginError(false);
      navigate("/ManagerHome");      
    } else {
      setShowLoginError(true);
    }
  };

  return (
    <>
      <div class="ui centered grid container" >
        <div class="six wide column ">
          {
            (showLoginError) ? 
              (
                <div class="ui icon warning message">
                  <i class="lock icon"></i>
                  <div class="content">
                    <div class="header">Sorry, login error!</div>
                    <p>You may have entered an invalid user id or password</p>
                  </div>
                  </div>
              ) : (<div></div>)
          }

          <div class="ui fluid card" >
            <div class="content" >
              <Form onSubmit={handleSubmit}>
                <Form.Field>
                  <label>User ID</label>
                  <Input icon='user' iconPosition='left' placeholder='User ID' onChange={(e) => setusername(e.target.value)} />
                </Form.Field>
                <Form.Field>
                  <label>Password</label>
                  <Input icon='lock' iconPosition='left' placeholder='Password'  onChange={(e) => setpassword(e.target.value)} type="password"/>
                </Form.Field>
                <Button primary labeled icon type='submit'>
                  <i class="unlock alternate icon"></i>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </Button>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </>
  )
};

export default Login;