import { useEffect, useState  } from "react";
import { Button, Icon, Image} from 'semantic-ui-react';
import { useNavigate } from "react-router-dom";
import axios from "axios";
import dayjs from "dayjs";
import {NumericFormat, PatternFormat}  from 'react-number-format';
import myImage from './images.png'

const ManagerHome = () => {
    window.onbeforeunload = function() {
        localStorage.clear();
    }
    useEffect(() => {
        const loggedInUser = localStorage.getItem("authenticated");
        if (loggedInUser) {
            setauthenticated(loggedInUser);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, []);

    const navigate = useNavigate();
    const [authenticated, setauthenticated] = useState(null);
    const [loggedInUser, setLoggedInUser] = useState(localStorage.getItem("loginUser"));
    const [data, setData] = useState([]);

    const fetchData = () => {
        axios.get('http://localhost:8080/api/claims/manager/' + loggedInUser)
            .then((response) => {
                setData(response.data);
            })
            .catch((err) => {
                console.log(err.message);
            });
    };

    function approveRequest(item) {
        const claims = [        
            {
                "claimId" : item.claimId,
                "employeeId": item.employeeId,
                "amount": item.amount, 
                "description": item.description, 
                "category": item.category, 
                "status": "Approved", 
                "submittedDate":item.submittedDate,
                "managerId": item.managerId,
                "category": item.category
            }
        ]

        axios.put('http://localhost:8080/api/claims',
            claims,
            {headers:
                {
                'Access-Control-Allow-Origin':'*',
                'Content-Type': 'application/json;charset=UTF-8',
                'Access-Control-Allow-Credentials':'true'
                }
            })
            .then(response => {
                fetchData();
            })
            .catch(e => {
                console.log(e);
            })
    }

    function rejectRequest(item) {
        const claims = [        
            {
                "claimId" : item.claimId,
                "employeeId": item.employeeId,
                "amount": item.amount, 
                "description": item.description, 
                "category": item.category, 
                "status": "Rejected", 
                "submittedDate":item.submittedDate,
                "managerId": item.managerId,
                "category": item.category
            }
        ]

        axios.put('http://localhost:8080/api/claims',
            claims,
            {headers:
                {
                'Access-Control-Allow-Origin':'*',
                'Content-Type': 'application/json;charset=UTF-8',
                'Access-Control-Allow-Credentials':'true'
                }
            })
            .then(response => {
                fetchData();
            })
            .catch(e => {
                console.log(e);
            })

    }
 
    if (!localStorage.getItem("authenManager")) {
        return <navigate to="/Login" replace />;
    } else {
        return (
        <>
        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center', border: '0px !important'}}>
            <table class="ui celled compact table" style={{width: '70%', border: 'none'}}>
                <tr style={{width: '70%', border: '0px'}}>
                    <td style={{textAlign: 'right', width: '10%'}}>
                        <Image src={myImage} size='small'/>
                    </td>
                    <td style={{textAlign: 'center', width: '80%'}}><h1>Employee Claim Record</h1></td>
                    <td style={{textAlign: 'center', width: '10%'}}><a href="/Login">logout</a></td>
                </tr>
                <tr>
                    <th colspan="3" style={{textAlign: 'right'}}></th>
                </tr>
            </table>
        </div>
        
        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
            <table class="ui celled compact table" style={{width: '70%'}}>
                <thead style={{textAlign:'center'}}>
                    <tr>
                        <th style={{width: '2%'}}>
                            <div class="ui fitted checkbox">
                                <input type="checkbox" readonly="" tabindex="0"/><label></label>
                            </div>
                        </th>
                        <th style={{width: '8%'}}>Claim ID</th>
                        <th style={{width: '10%'}}>Employee Name</th>
                        <th style={{width: '10%'}}>Category</th>
                        <th style={{width: '5%'}}>Amount</th>
                        <th style={{width: '45%'}}>Description</th>
                        <th style={{width: '5%'}}>Status</th>
                        <th style={{width: '5%'}}>Submitted</th>
                        <th style={{width: '10%'}} colSpan={2}>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item, index) => (
                    <tr key={index}>
                        <td style={{textAlign:'center'}}>
                            <div class="ui fitted checkbox">
                                <input type="checkbox" readonly="" tabindex="0"/><label></label>
                            </div>
                        </td>
                        <td style={{textAlign:'center'}}>{item.claimId}</td>
                        <td>{item.name}</td>
                        <td>{item.category}</td>            
                        <td>
                            <NumericFormat value={item.amount} displayType={'text'} thousandSeparator={true} prefix={'$'} decimalScale={2} />
                        </td>
                        <td>{item.description}</td>
                        <td>{item.status}</td>
                        <td style={{textAlign:'center'}}>{dayjs(item.submittedDate).format('DD-MM-YYYY')}</td>
                        <td style={{textAlign:'center'}}>
                            <Icon color='green' name='check' onClick={(e, {value}) => {approveRequest(item)}} value={item.claimId} />
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Icon color='read' name='cancel' onClick={(e, {value}) => {rejectRequest(item)}} value={item.claimId} />
                        </td>
                    </tr>
                    ))}
                </tbody>
            </table>
        </div>

        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
        <table class="ui celled compact table" style={{width: '70%'}}>
            <tr>
                <td>
                    <Button size="small" positive>
                        Approve Selected
                    </Button>
                    <Button color='black' size="small" >
                        Reject Selected
                    </Button>
                </td>
            </tr>
        </table>
        </div>
    </>
  )}
}

export default ManagerHome;