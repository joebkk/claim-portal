import React from 'react'
import { Button, Modal, Input,Form,Select,TextArea, Icon } from 'semantic-ui-react'

function ClaimFormModal(props) {
    const [open, setOpen] = React.useState(false);
    const [name, setName] = React.useState(0);
    const [managerId, setManagerId] = React.useState(0);
    const [amount, setAmount] = React.useState('');
    const [category, setCategory] = React.useState('');
    const [desc, setDesc] = React.useState('');  

    const optionsCategory = [
        { key: 't', text: 'Transport', value: 'Transport' },
        { key: 'a', text: 'Meal', value: 'Meal' },
        { key: 'c', text: 'Medical', value: 'Medical' },
        { key: 'r', text: 'Traning', value: 'Traning' },
        { key: 'm', text: 'Mobile', value: 'Mobile' },
        { key: 'o', text: 'Other', value: 'Other' },
    ]

    const optionsManager = [
        { key: 's', text: 'Scott Tiger', value: '404' },
        { key: 'd', text: 'David Cheetah', value: '401' },
        { key: 'j', text: 'James Lion', value: '402' },
        { key: 'b', text: 'Bob Leopard', value: '403' },        
    ]

    return (
        <Modal
            onClose={() => setOpen(false)}
            onOpen={() => setOpen(true)}
            open={open}
            trigger={<Button positive icon labelPosition='left' size='small'><Icon name='plus' />New Claim</Button>}
        >

        <Modal.Header>Expense Claim Form</Modal.Header>
        <Modal.Content>
            <Form>
            <Form.Group widths='equal'>
            <Form.Field
                control={Select}
                options={optionsManager}
                label='Approval Manager'
                placeholder='Approval Manager'
                onChange={(e, {value}) => {
                    setManagerId(value);
                }}
            />
            <Form.Field
                control={Input}
                label='Amount'
                placeholder='Amount'
                onChange={(e) => {
                    setAmount(e.target.value);
                }}
            />
            <Form.Field
                control={Select}
                options={optionsCategory}
                label='Category'
                placeholder='Category'
                onChange={(e) => {
                    setCategory(e.target.textContent);
                }}
            />
            </Form.Group>
            <Form.Field
                control={TextArea}
                label='Description'
                placeholder='Tell us more about claim detail...'
                onChange={(e) => {
                    setDesc(e.target.value);
                }}
                />
            </Form>   
        </Modal.Content>
        <Modal.Actions>
            <Button color='black' onClick={() => setOpen(false)}>
                Cancel
            </Button>
            <Button
                content="Submit"
                labelPosition='right'
                icon='checkmark'
                onClick={(e) => {setOpen(false); props.newClaim(managerId, amount, desc, category);}}
                positive
            />
        </Modal.Actions>
        </Modal>
  )
}

export default ClaimFormModal
