import axios from 'axios';

const CLAIM_API_BASE_URL = "http://localhost:8080/api/claims";

export default axios.create({
    baseURL: CLAIM_API_BASE_URL,
    headers: {
        'Access-Control-Allow-Origin':'*',
        'Content-Type': 'application/json;charset=UTF-8',
        'Access-Control-Allow-Credentials':'true'
    }
});