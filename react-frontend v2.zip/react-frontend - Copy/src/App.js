import './App.css';
import 'semantic-ui-css/semantic.min.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ManagerHome from "./ManagerHome";
import Login from "./Login";
import EmployeeHome from "./EmployeeHome";

function App() {
  return (
    <div>
      <Router>
           <Routes>
                 <Route exact path='/' element={< Login />}></Route>
                 <Route exact path='/Login' element={< Login />}></Route>
                 <Route exact path='/ManagerHome' element={< ManagerHome />}></Route>
                 <Route exact path='/EmployeeHome' element={< EmployeeHome />}></Route>
          </Routes>
       </Router>
    </div>
  );
}

export default App;
