import React from 'react'
import { useEffect, useState } from 'react';
import { Image, Icon } from 'semantic-ui-react'
import ClaimFormModal from "./Modal";
import { Navigate } from "react-router-dom";
import myImage from './images.png'
import dayjs from "dayjs";
import {NumericFormat, PatternFormat }  from 'react-number-format';
import api from "./Api/ClaimApi"

const EmployeeHome = () => {
    const [show, setShow] = useState(true);
    const [open, setOpen] = useState(true);
    const [authenticated, setAuthenticated] = useState(null);
    const [loggedInUser, setLoggedInUser] = useState(localStorage.getItem("loginUser"));
    const [loggedInUserName, setLoggedInUserName] = useState(localStorage.getItem("loginName"));
    const [data, setData] = useState([]);

    window.onbeforeunload = function() {
        localStorage.clear();
    }

    useEffect(() => {
        const loggedInUser = localStorage.getItem("loginUser");
        if (loggedInUser) {
            setAuthenticated(true);
        }
        fetchData();
    }, []);

    function toggleShow() {
        setShow(!show);
    }

    async function fetchData() {
        const response = await api
            .get("/employee/" + loggedInUser)
            .catch((error) => {
                console.log(error.message);
            });

        if (response.data) {
            setData(response.data.claims); 
        }
    }

    async function newClaim(managerId, managerName, amount, desc, category) {
        const employee = {
            "amount": amount, 
            "description": desc, 
            "category":category, 
            "status": "Pending", 
            "submittedDate": new Date(),
            "managerId": managerId,
            "managerName" : managerName,
            "employeeName" : loggedInUserName,
            "employee": {"id": loggedInUser}
        }

        const response = await api
            .post("", employee)
            .catch(error => {
                console.log(error);
            })
            fetchData();
    }

    const tablebody = (data && data.length > 0) ? 
    (
        <>    
        {
           data.map((item, index) => (              
            <tr key={index}>
                <td style={{textAlign:'center'}}>
                    {item.claimId}
                </td>
                <td style={{textAlign:'center'}}>
                    {dayjs(item.submittedDate).format('DD-MM-YYYY')}
                </td>
                <td>{item.description}</td>
                <td>{item.category}</td>
                <td style={{textAlign:'right'}}>
                    <NumericFormat value={item.amount} displayType={'text'} thousandSeparator={true} prefix={'$ '} decimalScale={2} fixedDecimalScale />
                </td>
                <td>{item.managerName}</td>
                <td style={{textAlign:'center'}}>
                    { 
                        (() => {
                                switch (item.status) {
                                    case "Approved": return <><Icon color='green' name='check'></Icon>Approved</>;
                                    case "Rejected": return <><Icon color='red' name='cancel'></Icon>Rejected</>;
                                    default: return <><Icon name='hourglass outline'></Icon>Pending</>;
                                } 
                            }
                        )()
                    }             
                </td>     
            </tr>
            ))
        }
        </>             
    ) : (
        <>
            <tr>
                <th colspan="6">&nbsp;</th>
            </tr>
            <tr style={{textAlign:'center'}}>
                <th colspan="6">You do not have any claim record.</th>
            </tr>
            <tr>
                <th colspan="6">&nbsp;</th>
            </tr>
        </>
    )

    return (
        <>
        {!localStorage.getItem("authenEmployee") ? 
            ( <Navigate  replace to="/Login" /> ) : 
            (
                <>
                <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
                    <table class="ui celled compact table" style={{width: '70%', border: 'none'}}>
                        <tr style={{width: '70%', border: '0px'}}>
                            <th style={{textAlign: 'right', width: '10%'}}>
                                <Image src={myImage} size='small' />
                            </th>
                            <th style={{textAlign: 'center', width: '60%'}}>
                                <h1>My Claim Record(s)</h1>
                            </th>
                            <td style={{textAlign: 'center', width: '20%'}}>
                                Welcome!&nbsp;&nbsp;{loggedInUserName}
                            </td>
                            <th style={{textAlign: 'center', width: '10%'}}>
                                <a href="/Login">logout</a>
                            </th>
                        </tr>
                        <tr>
                            <th colspan="4" style={{textAlign: 'right'}}>
                                <ClaimFormModal newClaim={newClaim} />
                            </th>
                        </tr>
                    </table>
                </div>
                <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
                    <table class="ui celled sortable table" style={{width: '70%', alignContent: 'center', borderBottom: 'medium'}}>
                        <thead style={{textAlign:'center'}}>
                            <tr>
                                <th style={{width: '8%'}}>Claim ID</th>
                                <th style={{width: '12%'}}>Submitted Date</th>
                                <th style={{width: '40%'}}>Description</th>
                                <th style={{width: '10%'}}>Category</th>    
                                <th style={{width: '10%'}}>Amount</th>
                                <th style={{width: '10%'}}>Approval Manger</th>    
                                <th style={{width: '10%'}}>Status</th> 
                            </tr>
                        </thead>
                        <tbody>
                            {tablebody}
                        </tbody>
                    </table>
                </div>
                <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
                    <table class="ui celled compact table" style={{width: '70%', alignContent: 'center', borderBottom: 'medium'}}>  
                    </table>
                </div>
                </>
            )}
        </>
    );
}

export default EmployeeHome;