import React, { useState } from "react";
import { Button, Form, Input, Message } from 'semantic-ui-react'
import { useNavigate } from "react-router-dom";
import './App.css';
import myImage from './DSC_7130-mono-scaled.jpg'

const Login = () => {
  const navigate = useNavigate();
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [password, setpassword] = useState("");  
  const [showLoginError, setShowLoginError] = useState(false);
  const users = [
    { id: "101", password: "101", name: "Joe RUNGROATH" }, 
    { id: "102", password: "102", name: "Yan Ru TAN" }, 
    { id: "103", password: "103", name: "Benson LIM" }, 
    { id: "104", password: "104", name: "Lilian WEI" }, 
  ];
  const managers = [
    { id: "401", password: "401", name: "Scott Tiger" },
    { id: "402", password: "402", name: "David Cheetah" },
    { id: "403", password: "403", name: "James Lion" },
    { id: "404", password: "404", name: "Bob Leopard" },
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const empAccount = users.find((user) => user.id === id);
    if (empAccount && empAccount.password === password) {
      localStorage.setItem("authenEmployee", true);
      localStorage.setItem("loginUser", empAccount.id);
      localStorage.setItem("loginName", empAccount.name);
      setShowLoginError(false);
      navigate("/EmployeeHome");
    } else {
      setShowLoginError(true);
    }

    const mgrAccount = managers.find((user) => user.id === id);
    if (mgrAccount && mgrAccount.password === password) {
      localStorage.setItem("authenManager", true);
      localStorage.setItem("loginUser", mgrAccount.id);
      localStorage.setItem("loginName", mgrAccount.name);
      setShowLoginError(false);
      navigate("/ManagerHome");      
    } else {
      setShowLoginError(true);
    }
  };

  return (
    <div style={{backgroundImage: 'url(https://b.rgbimg.com/users/x/xy/xymonau/600/o14tpzA.jpg)', backgroundRepeat: 'no-repeat', backgroundSize: '100%', backgroundPosition: 'center'}}>
      <div class="ui centered grid container" style={{display: 'flex', minHeight: 1000, alignItems: 'center', justifyContent: 'center', textAlign: 'center'}}>      
        <div class="six wide column">
        {
            (showLoginError) ? 
              (
                <div class="ui icon error message">
                  <i class="frown outline icon"></i>
                  <div class="content">
                    <div class="header">ERROR: Login failed!</div>
                    <p>Incorrect user ID and/or password</p>
                  </div>
                  </div>
              ) : (<div></div>)
          }
          <div class="ui icon message" style={{display: 'flex', alignItems: 'left', justifyContent: 'left', textAlign: 'left'}}>
            <h2>Login to Claim Portal</h2>            
          </div>
          <div class="ui fluid card" style={{display: 'flex', minHeight: 230, alignItems: 'center', justifyContent: 'center', textAlign: 'center', width: '100%'}}>
            Sign in to your account to continue.
            <br/><br/>            
            <Form onSubmit={handleSubmit}>
              <Form.Field>
                <Input icon='user' iconPosition='left' placeholder='User ID' onChange={(e) => setId(e.target.value)} />
              </Form.Field>
              <Form.Field>
                <Input icon='lock' iconPosition='left' placeholder='Password'  onChange={(e) => setpassword(e.target.value)} type="password"/>
              </Form.Field>
              <Button primary labeled icon type='submit'>
                <i class="unlock alternate icon"></i>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </Button>
            </Form>
          </div>
        </div>
      </div>
    </div>
  )
};

export default Login;