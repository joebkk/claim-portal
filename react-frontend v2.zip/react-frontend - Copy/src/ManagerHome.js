import { useEffect, useState  } from "react";
import { Button, Icon, Image} from 'semantic-ui-react';
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import {NumericFormat, PatternFormat}  from 'react-number-format';
import myImage from './images.png'
import api from "./Api/ClaimApi"

const ManagerHome = () => {
    window.onbeforeunload = function() {
        localStorage.clear();
    }

    useEffect(() => {
        const loggedInUser = localStorage.getItem("authenticated");
        if (loggedInUser) {
            setauthenticated(loggedInUser);
        }

        fetchData();
    }, []);

    const navigate = useNavigate();
    const [authenticated, setauthenticated] = useState(null);
    const [loggedInUser, setLoggedInUser] = useState(localStorage.getItem("loginUser"));
    const [loggedInUserName, setLoggedInUserName] = useState(localStorage.getItem("loginName"));
    const [data, setData] = useState([]);
    const [checked, setChecked] = useState([]);

    const handleCheckAllChange = (e) => {
        if (e.target.checked) {
          const allClaims = data.map((item) => item.claimId);
          setChecked(allClaims);
        } else {
          setChecked([]);
        }
    };

    const handleClaimIdChecked = (e, item) => {
        if (e.target.checked) {
            setChecked([...checked, item.claimId]);
        } else {
            setChecked(checked.filter((c) => c !== item.claimId));
        }
    };

    async function fetchData() {
        const response = await api
            .get("/manager/" + loggedInUser)
            .catch((error) => {
                console.log(error.message);
            });
            console.log(response.data)
        setData(response.data);
    }

    async function updateAllSelected(e, type) {
        let output = '[';
        checked.map((claimId, index) => {
            if (index+1 != checked.length) {
                output += '{"claimId": ' + claimId + ', "status": "' + type + '"},'
            } else {
                output += '{"claimId": ' + claimId + ', "status": "' + type + '"}]'
            }
        })

        const response = await api
            .put("", output)
            .catch(error => {
                console.log(error);
            })
        fetchData();
    }

    async function updateClaimStatus(item, type) {
        const claims = [        
            {
                "claimId": item.claimId,
                "status": type
            }
        ]

        const response = await api
            .put("", claims)
            .catch(error => {
                console.log(error);
            })
        fetchData();
    }

    const tablebody = (data.length > 0) ? 
    (
        <>    
        { 
            data.map((item, index) => (              
            <tr key={index}>
                <td style={{textAlign:'center'}}>
                    <div class="ui fitted checkbox">
                        <input type="checkbox" readonly="" tabindex="0" 
                            onChange={(e) => handleClaimIdChecked(e, item)} 
                            checked={checked.includes(item.claimId)}/><label></label>
                    </div>
                </td>
                <td style={{textAlign:'center'}}>{item.claimId}</td>
                <td>{item.employeeName}</td>         
                <td>{item.category}</td>            
                <td>
                    <NumericFormat value={item.amount} displayType={'text'} thousandSeparator={true} prefix={'$ '} decimalScale={2} fixedDecimalScale />
                </td>
                <td>{item.description}</td>
                <td>{item.status}</td>
                <td style={{textAlign:'center'}}>{dayjs(item.submittedDate).format('DD-MM-YYYY')}</td>
                <td style={{textAlign:'center'}}>
                    <Icon color='green' name='check' 
                        onClick={(e, {value}) => {updateClaimStatus(item, 'Approved')}} 
                        value={item.claimId} />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Icon color='red' name='cancel' 
                        onClick={(e, {value}) => {updateClaimStatus(item, 'Rejected')}} 
                        value={item.claimId} />
                </td>
            </tr>
            ))
        }
        </>             
    ) : (
            <>
                <tr>
                    <th colspan="10">&nbsp;</th>
                </tr>
                <tr style={{textAlign:'center'}}>
                    <th colspan="10">You do not have any claim record.</th>
                </tr>
                <tr>
                    <th colspan="10">&nbsp;</th>
                </tr>
            </> 
    )
   
    if (!localStorage.getItem("authenManager")) {
        return <navigate to="/Login" replace />;
    } else {  
        return (
        <>
        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
            <table class="ui celled compact table" style={{width: '70%', border: 'none'}}>
                <tr style={{width: '70%', border: '0px'}}>
                    <td style={{textAlign: 'right', width: '10%'}}>
                        <Image src={myImage} size='small'/>
                    </td>
                    <td style={{textAlign: 'center', width: '65%'}}>
                        <h1>Manager View for Claim Record(s)</h1>
                    </td>
                    <td style={{textAlign: 'center', width: '15%'}}>
                                Welcome!&nbsp;&nbsp;{loggedInUserName}
                    </td>
                    <td style={{textAlign: 'center', width: '10%'}}><a href="/Login">logout</a></td>
                </tr>
                <tr>
                    <th colspan="3" style={{textAlign: 'right'}}></th>
                </tr>
            </table>
        </div>
        
        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
            <table class="ui celled sortable table" style={{width: '70%'}}>
                <thead style={{textAlign:'center'}}>
                    <tr>
                        <th style={{width: '2%'}}>
                            <div class="ui fitted checkbox">
                                <input type="checkbox" readonly="" tabindex="0" 
                                    onChange={handleCheckAllChange}/>
                                    <label></label>
                            </div>
                        </th>
                        <th style={{width: '5%'}}>Claim ID</th>                        
                        <th style={{width: '15%'}}>Employee Name</th>
                        <th style={{width: '10%'}}>Category</th>
                        <th style={{width: '10%'}}>Amount</th>
                        <th style={{width: '30%'}}>Description</th>
                        <th style={{width: '10%'}}>Status</th>
                        <th style={{width: '10%'}}>Submitted</th>
                        <th style={{width: '10%'}} colSpan={2}>Action</th>
                    </tr>
                </thead>
                <tbody>
                    { tablebody }
                </tbody>
            </table>
        </div>

        <div style={{display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'center'}}>
        <table class="ui celled compact table" style={{width: '70%'}}>
            <tr>
                <td>
                    <Button textAlign="middle" size="small" positive onClick={e => updateAllSelected(e, 'Approved')}>
                        Approve Selected
                    </Button>
                    <Button textAlign="middle" color='red' size="small" onClick={e => updateAllSelected(e, 'Rejected')}>
                        Reject Selected &nbsp;
                    </Button>
                </td>
            </tr>
        </table>
        </div>
    </>
  )}
}

export default ManagerHome;